# Projeto 2 de Introducao ao Processamento de Imagens - UnB
# Aluno: Bruno Takashi Tengan
# Matricula: 12/0167263

# Programas desenvolvidos em python 3 em linux Ubuntu 16.

# Para executar os programas basta executálos do diretorio raiz da pasta do trabalho.
# ex: python3 src/questao1.py